const STYLE =
'@media (max-width: 640px) {\n' +
'  body {\n' +
'    overflow-x: hidden;\n' +
'  }\n' +
'\n' +
'  div#container {\n' +
'    min-width: initial;\n' +
'  }\n' +
'\n' +
'  div.memberwrapper {\n' +
'    z-index: 10000011;\n' +
'    top: 0;\n' +
'    position: absolute;\n' +
'    box-shadow: 2px 0px 10px #333;\n' +
'    transform: translateX(170px);\n' +
'    visibility: hidden;\n' +
'    transition: all 0.2s ease;\n' +
'  }\n' +
'\n' +
'  body.rightbar div.memberwrapper {\n' +
'    transform: translateX(0);\n' +
'    visibility: visible;\n' +
'  }\n' +
'\n' +
'  div.buffermainwrapper {\n' +
'    position: initial;\n' +
'  }\n' +
'\n' +
'  div#sidebarwrapper {\n' +
'    z-index: 10000011;\n' +
'    left: 0;\n' +
'    overflow-y: auto;\n' +
'    background-color: #C0DBFF;\n' +
'    box-shadow: 0px 0px 10px #333;\n' +
'    transform: translateX(-201px);\n' +
'    visibility: hidden;\n' +
'    transition: all 0.2s ease;\n' +
'  }\n' +
'\n' +
'  body.leftbar div#sidebarwrapper {\n' +
'    transform: translateX(0);\n' +
'    visibility: visible;\n' +
'  }\n' +
'\n' +
'  #headercell {\n' +
'    display: none;\n' +
'  }\n' +
'\n' +
'  #mainwrapper {\n' +
'    padding: 0;\n' +
'  }\n' +
'\n' +
'  .mainContainer, table.buffer {\n' +
'    border: none;\n' +
'    table-layout: fixed;\n' +
'  }\n' +
'\n' +
'  td.statuscell div.status h2.bufferHeading span.label {\n' +
'    display: block;\n' +
'    margin: 0;\n' +
'    line-height: 30px;\n' +
'    padding: 0px 2rem;\n' +
'    white-space: nowrap;\n' +
'    max-width: 100%;\n' +
'    overflow: hidden;\n' +
'    text-overflow: ellipsis;\n' +
'  }\n' +
'\n' +
'  .buffer.conversation td.statuscell div.status h2.bufferHeading span.label {\n' +
'    padding: 0 0 0 2rem;\n' +
'  }\n' +
'\n' +
'  .showMembers div.buffermain {\n' +
'    padding: 0;\n' +
'  }\n' +
'\n' +
'  .time-24hr.time-noseconds td.timecell, #timeContainer {\n' +
'    display: none;\n' +
'  }\n' +
'\n' +
'  div.nickinputwrapper {\n' +
'    margin: 9px 9px 10px 9px;\n' +
'  }\n' +
'\n' +
'  .extras span.extrasBar {\n' +
'    font-size: 10px;\n' +
'  }\n' +
'\n' +
'  div.dateWrapper table, div.log div.dateChange p {\n' +
'    font-size: 11px;\n' +
'  }\n' +
'\n' +
'  td.statuscell div.status h2.bufferHeading {\n' +
'    font-size: 10px;\n' +
'    padding: 0px;\n' +
'  }\n' +
'\n' +
'  span.topic {\n' +
'    display: none; /* hide, for now */\n' +
'  }\n' +
'\n' +
'  .bufferHead {\n' +
'    padding: 2px;\n' +
'    height: 30px;\n' +
'  }\n' +
'\n' +
'  td.statuscell {\n' +
'    height: 30px;\n' +
'  }\n' +
'\n' +
'  div.log div.me a.server,\n' +
'  div.log div.me a.user,\n' +
'  div.log div.messageRow,\n' +
'  div.shim,\n' +
'  td.inputcell textarea,\n' +
'  td.nickcell a.nick {\n' +
'    font-size: 12px;\n' +
'  }\n' +
'\n' +
'  td.statuscell div.status p.buttons button.options {\n' +
'    width: 2rem;\n' +
'    height: 2rem;\n' +
'    position: relative;\n' +
'  }\n' +
'\n' +
'  button.responsive-addon {\n' +
'    padding: 0;\n' +
'    width: 2rem;\n' +
'    height: 2rem;\n' +
'    position: absolute;\n' +
'    font-size: 1.8rem;\n' +
'    line-height: 2rem;\n' +
'    transition: visibility 0.0s linear 0.2s;\n' +
'    background-position: center center;\n' +
'    background-repeat: no-repeat;\n' +
'    background-size: 70%;\n' +
'    display: none;\n' +
'  }\n' +
'\n' +
'  body.inchannel #buffersContainer.canShow.show ~ button#membersListBtn,\n' +
'  body:not(.loading) #buffersContainer.canShow ~ button#bufferMenuBtn {\n' +
'    display: block;\n' +
'  }\n' +
'\n' +
'  button#bufferMenuBtn {\n' +
'    top: 1px;\n' +
'    left: 1px;\n' +
'    background-image: url("data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+IDxzdmcgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpjYz0iaHR0cDovL2NyZWF0aXZlY29tbW9ucy5vcmcvbnMjIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiIHhtbG5zOnN2Zz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgdmVyc2lvbj0iMS4xIiBpZD0ic3ZnMiIgdmlld0JveD0iMCAwIDMyIDMyIiBoZWlnaHQ9IjMyIiB3aWR0aD0iMzIiPiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwLC0xMDIwLjM2MjIpIiBpZD0ibGF5ZXIxIj4gPHJlY3QgeT0iMTAyMy44NjIyIiB4PSIxIiBoZWlnaHQ9IjUiIHdpZHRoPSIzMCIgaWQ9InJlY3Q0MjQ4IiBzdHlsZT0iZmlsbDojMDAwMDAwO2ZpbGwtb3BhY2l0eToxO3N0cm9rZTpub25lO3N0cm9rZS13aWR0aDo1O3N0cm9rZS1taXRlcmxpbWl0OjQ7c3Ryb2tlLWRhc2hhcnJheTpub25lO3N0cm9rZS1vcGFjaXR5OjEiIC8+IDxyZWN0IHN0eWxlPSJmaWxsOiMwMDAwMDA7ZmlsbC1vcGFjaXR5OjE7c3Ryb2tlOm5vbmU7c3Ryb2tlLXdpZHRoOjU7c3Ryb2tlLW1pdGVybGltaXQ6NDtzdHJva2UtZGFzaGFycmF5Om5vbmU7c3Ryb2tlLW9wYWNpdHk6MSIgaWQ9InJlY3Q0MjUwIiB3aWR0aD0iMzAiIGhlaWdodD0iNSIgeD0iMSIgeT0iMTAzMy44NjIyIiAvPiA8cmVjdCB5PSIxMDQzLjg2MjIiIHg9IjEiIGhlaWdodD0iNSIgd2lkdGg9IjMwIiBpZD0icmVjdDQyNTIiIHN0eWxlPSJmaWxsOiMwMDAwMDA7ZmlsbC1vcGFjaXR5OjE7c3Ryb2tlOm5vbmU7c3Ryb2tlLXdpZHRoOjU7c3Ryb2tlLW1pdGVybGltaXQ6NDtzdHJva2UtZGFzaGFycmF5Om5vbmU7c3Ryb2tlLW9wYWNpdHk6MSIgLz4gPC9nPiA8L3N2Zz4g");\n' +
'  }\n' +
'\n' +
'  button#membersListBtn {\n' +
'    top: 1px;\n' +
'    right: calc(2rem + 2px);\n' +
'    background-image: url("data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjxzdmcKICAgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIgogICB4bWxuczpjYz0iaHR0cDovL2NyZWF0aXZlY29tbW9ucy5vcmcvbnMjIgogICB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiCiAgIHhtbG5zOnN2Zz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciCiAgIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIKICAgdmVyc2lvbj0iMS4xIgogICBpZD0ic3ZnMiIKICAgdmlld0JveD0iMCAwIDMyIDMyIgogICBoZWlnaHQ9IjMyIgogICB3aWR0aD0iMzIiPgogIDxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAsLTEwMjAuMzYyMikiPgogICAgPGcgdHJhbnNmb3JtPSJtYXRyaXgoMS43MjQ5NjcsMCwwLDEuNjk2NzI2LC05Ljg2MDY2MSwtNzMyLjUxMTY0KSIKICAgICAgIHN0eWxlPSJmaWxsOiMwMDAwMDA7ZmlsbC1vcGFjaXR5OjE7c3Ryb2tlOm5vbmU7c3Ryb2tlLXdpZHRoOjFweDtzdHJva2UtbGluZWNhcDpidXR0O3N0cm9rZS1saW5lam9pbjptaXRlcjtzdHJva2Utb3BhY2l0eToxIj4KICAgICAgPHBhdGgKICAgICAgICAgZD0ibSA3LjMyNjk1NTUsMTA1MS4yODg5IDAsLTIuMjQxMSBxIDAsLTAuOTExMiAwLjgxMjY3NywtMi4wMTkzIDAuODEyNjc3LC0xLjEyMDYgMS45ODI0Mzk1LC0xLjg4NCAxLjE4MjA3NSwtMC43NjM0IDIuMTE3ODg1LC0wLjc2MzQgbCAwLjIzMzk1MywwIDAsLTAuNzI2NSBxIC0wLjY3NzIzMSwtMC41NjY0IC0xLjIwNjcwMiwtMS44MSAtMC4zOTQwMjYsLTAuMTM1NSAtMC43MTQxNzEsLTAuNzM4OCAtMC4zMjAxNDYsLTAuNjAzNCAtMC4zMjAxNDYsLTEuMjA2NyAwLC0wLjMwNzkgMC4wODYxOSwtMC41MDQ5IDAuMDk4NTEsLTAuMjA5MyAwLjI3MDg5MywtMC4yMDkzIGwgLTAuMDQ5MjUsLTAuODM3MyBxIDAsLTIuMDE5NCAxLjI1NTk1NSwtMy4zIDEuMjU1OTU1LC0xLjI5MjkgMy4yMDE0NTUsLTEuMjkyOSAxLjI4MDU4MiwwIDIuMzE0ODk4LDAuNjE1NyAxLjAzNDMxNiwwLjYwMzMgMS41ODg0MTQsMS42NzQ2IDAuNTY2NDExLDEuMDcxMyAwLjU2NjQxMSwyLjM2NDIgbCAtMC4wMjQ2MywwLjY3NzIgcSAwLjQ0MzI3OSwwIDAuNDQzMjc5LDAuNjg5NSAwLDAuNzUxMSAtMC4zNTcwODYsMS4zNzkxIC0wLjM1NzA4NSwwLjYyOCAtMC43NTExMSwwLjcwMTkgLTAuNTE3MTU4LDEuMTY5NyAtMS4yMTkwMTYsMS43OTc3IGwgMCwwLjcyNjUgMC4xODQ3LDAgcSAwLjk0ODEyMywwIDIuMTQyNTEyLDAuNzg4IDEuMTk0Mzg5LDAuNzc1OCAxLjk4MjQzOSwxLjg3MTcgMC43ODgwNTEsMS4wODM1IDAuNzg4MDUxLDEuOTU3OCBsIDAsMi4yOTAzIC0xNS4zMzAwNDMzLDAgeiIgLz4KICAgIDwvZz4KICA8L2c+Cjwvc3ZnPgo=");\n' +
'  }\n' +
'\n' +
'  button#memberListBtn {\n' +
'    border: 1px solid green;\n' +
'  }\n' +
'\n' +
'\n' +
'  body.leftbar button#bufferMenuBtn,\n' +
'  body.rightbar button#memberListBtn {\n' +
'    visibility: hidden;\n' +
'    transition: none;\n' +
'  }\n' +
'\n' +
'  table.channel.active td.statuscell div.status p.buttons button:not(.options),\n' +
'  table td.statuscell div.status p.buttons button:not(.options) {\n' +
'    display: none;\n' +
'  }\n' +
'\n' +
'  td.statuscell div.status p.buttons button.options {\n' +
'    background-image: url("data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+IDxzdmcgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpjYz0iaHR0cDovL2NyZWF0aXZlY29tbW9ucy5vcmcvbnMjIiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiIHhtbG5zOnN2Zz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgdmVyc2lvbj0iMS4xIiBpZD0ic3ZnMiIgdmlld0JveD0iMCAwIDMyIDMyIiBoZWlnaHQ9IjMyIiB3aWR0aD0iMzIiPiA8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwLC0xMDIwLjM2MjIpIiBpZD0ibGF5ZXIxIj4gPGNpcmNsZSByPSIzIiBjeT0iMTAzNi4zNjIyIiBjeD0iMTYiIGlkPSJjaXJjbGU0MjkyIiBzdHlsZT0iZmlsbDojMDAwMDAwO2ZpbGwtb3BhY2l0eToxO3N0cm9rZTpub25lO3N0cm9rZS13aWR0aDo1O3N0cm9rZS1taXRlcmxpbWl0OjQ7c3Ryb2tlLWRhc2hhcnJheTpub25lO3N0cm9rZS1vcGFjaXR5OjEiIC8+IDxjaXJjbGUgc3R5bGU9ImZpbGw6IzAwMDAwMDtmaWxsLW9wYWNpdHk6MTtzdHJva2U6bm9uZTtzdHJva2Utd2lkdGg6NTtzdHJva2UtbWl0ZXJsaW1pdDo0O3N0cm9rZS1kYXNoYXJyYXk6bm9uZTtzdHJva2Utb3BhY2l0eToxIiBpZD0iY2lyY2xlNDI5OCIgY3g9IjE2IiBjeT0iMTAyNi4zNjIyIiByPSIzIiAvPiA8Y2lyY2xlIHI9IjMiIGN5PSIxMDQ2LjM2MjIiIGN4PSIxNiIgaWQ9ImNpcmNsZTQzMDAiIHN0eWxlPSJmaWxsOiMwMDAwMDA7ZmlsbC1vcGFjaXR5OjE7c3Ryb2tlOm5vbmU7c3Ryb2tlLXdpZHRoOjU7c3Ryb2tlLW1pdGVybGltaXQ6NDtzdHJva2UtZGFzaGFycmF5Om5vbmU7c3Ryb2tlLW9wYWNpdHk6MSIgLz4gPC9nPiA8L3N2Zz4g");\n' +
'    background-position: center center;\n' +
'    background-repeat: no-repeat;\n' +
'    background-size: 70%;\n' +
'  }\n' +
'\n' +
'  td.statuscell div.status p.buttons button.options > span {\n' +
'    font-size: 0;\n' +
'    border: none;\n' +
'  }\n' +
'\n' +
'  td.statuscell div.status p.buttons button.options > span > b {\n' +
'    display: none;\n' +
'  }\n' +
'\n' +
'  #memberContextMenu {\n' +
'    left: 5px !important;\n' +
'    top: 50px !important;\n' +
'    width: calc(100% - 10px);\n' +
'  }\n' +
'\n' +
'\n' +
'  h2#addNetworkHeading {\n' +
'    line-height: 30px;\n' +
'    background-position: 2rem 50%;\n' +
'    padding-left: 3.5rem;\n' +
'  }\n' +
'\n' +
'  #maintable {\n' +
'    table-layout: fixed;\n' +
'  }\n' +
'\n' +
'  form.addNetworkForm table.form {\n' +
'    width: 100%;\n' +
'  }\n' +
'\n' +
'  form.addNetworkForm table.form .hostname {\n' +
'    width: 60%;\n' +
'  }\n' +
'\n' +
'  form.addNetworkForm table.form .port, form.addNetworkForm table.form .ssl {\n' +
'    width: 20%;\n' +
'  }\n' +
'\n' +
'  form.addNetworkForm table.form input.addNetworkHostnameSelect {\n' +
'    width: calc(100% - 40px);\n' +
'  }\n' +
'\n' +
'  form.addNetworkForm table.form input.addNetworkPort {\n' +
'    width: calc(100% - 20px);\n' +
'  }\n' +
'\n' +
'  form.addNetworkForm span.addNetworkafterSSL {\n' +
'    font-size: 0;\n' +
'  }\n' +
'\n' +
'  form.addNetworkForm table.form td, form.addNetworkForm table.form th {\n' +
'    width: 50%;\n' +
'  }\n' +
'\n' +
'  form.addNetworkForm table.form .input,\n' +
'  form.addNetworkForm table.form textarea.addNetworkChannels {\n' +
'    width: calc(100% - 10px);\n' +
'  }\n' +
'\n' +
'  #mainwrapper {\n' +
'    overflow-y: auto;\n' +
'  }\n' +
'\n' +
'  td.statuscell div.status .identity,\n' +
'  table.password td.statuscell div.status h2.bufferHeading, table.server td.statuscell div.status h2.bufferHeading .host {\n' +
'    display: none; /* todo: we should reexpose this */\n' +
'  }\n' +
'\n' +
'  table.ssl td.statuscell div.status h2.bufferHeading {\n' +
'    background-position: 2rem 8px;\n' +
'  }\n' +
'\n' +
'\n' +
'  /* file upload */\n' +
'  .accountContainer {\n' +
'    left: 0;\n' +
'    top: 0;\n' +
'    width: calc(100% - 50px);\n' +
'    margin-left: 0;\n' +
'  }\n' +
'\n' +
'  #fileUploadContainer p.form input.input,\n' +
'  #pastebinContainer p.form input.input {\n' +
'    width: calc(100% - 6px);\n' +
'  }\n' +
'\n' +
'  .overlay_container_prompt {\n' +
'    left: 6%;\n' +
'    width: 88%;\n' +
'  }\n' +
'\n' +
'  /* For entrprise login screen */\n' +
'\n' +
'  #enterpriseLanding {\n' +
'    box-shadow: initial;\n' +
'    width: initial;\n' +
'    margin: initial;\n' +
'    border-radius: initial;\n' +
'  }\n' +
'\n' +
'  #landingFooter .landingContainer > p:nth-child(1) {\n' +
'    display: none;\n' +
'  }\n' +
'\n' +
'  #landingFooter .landingContainer > p {\n' +
'    padding: 0;\n' +
'  }\n' +
'\n' +
'  #logo {\n' +
'    font-size: 20px;\n' +
'  }\n' +
'\n' +
'  #enterpriseLogin > p:nth-child(1) {\n' +
'    font-size: .75em;\n' +
'  }\n' +
'\n' +
'  #enterpriseLogin {\n' +
'    width: 100%;\n' +
'  }\n' +
'\n' +
'  /* splash */\n' +
'\n' +
'  #splash {\n' +
'    position: absolute;\n' +
'    top: 0;\n' +
'    bottom: 0;\n' +
'    left: 0;\n' +
'    right: 0;\n' +
'    background-color: #C0DBFF;\n' +
'    display: none;\n' +
'  }\n' +
'\n' +
'  .loading #splash {\n' +
'    display: block;\n' +
'  }\n' +
'\n' +
'  .spinner {\n' +
'    display: inline-block;\n' +
'    position: absolute;\n' +
'    top: 30%;\n' +
'    left: 50%;\n' +
'    transform: translate(-50%, -50%);\n' +
'  }\n' +
'\n' +
'  .spinner > div {\n' +
'    height: 60px;\n' +
'    width: 60px;\n' +
'    margin: 94px auto 0 auto;\n' +
'    position: relative;\n' +
'    animation: rotation .6s infinite linear;\n' +
'    border-left: 6px solid #1E72FF;\n' +
'    border-right: 6px solid #1E72FF;\n' +
'    border-bottom: 6px solid #1E72FF;\n' +
'    border-top: 6px solid #123E92;\n' +
'    border-radius: 100%;\n' +
'  }\n' +
'\n' +
'  @keyframes rotation {\n' +
'    from {\n' +
'      transform: rotate(0deg);\n' +
'    }\n' +
'    to {\n' +
'      transform: rotate(359deg);\n' +
'    }\n' +
'  }\n' +
'}';

window.addEventListener('DOMContentLoaded', function() {
  var styletag = document.createElement('style');
  styletag.textContent = STYLE;
  document.head.appendChild(styletag);
});
